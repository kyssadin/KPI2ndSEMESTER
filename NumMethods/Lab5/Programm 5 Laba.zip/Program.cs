﻿using System;

namespace NumMethods5
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] x = {-3, -1, 1, 3, 5};
            double[] y = {-1.102554, -2.439745, 2.439745, 1.102554, 3.404212};
            for (int i = 0; i < x.GetLength(0); i++)
            {
                Console.WriteLine($"| x[{i}] = {x[i]}  \t y[{i}] = {y[i]}");
            }

            Console.WriteLine("\n\nThe Newton's polynomial : ");
            Functions.newtMethod(x, y, 5);


            Console.WriteLine("\nCubic spline interpolation : ");
            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine($"Values from x = {x[i]} to x = {x[i + 1]} : ");
                Functions.cubSplineInterp(x, y, 5, x[i]);
            }
        }
    }
}
